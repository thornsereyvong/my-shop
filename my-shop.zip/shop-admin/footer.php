<?php
/*
 * *****************************************************************************
 * file: footer.php
 * @autor: Thorn sereyvong
 * @date: 08-09-2015
 * ZOBENZ TEAM
 * *****************************************************************************
 */
?>

	
	
	
	<script src="<?php echo $server; ?>bootstrap/js/jquery.form.js"></script>
	<script src="<?php echo $server; ?>bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo $server; ?>bootstrap/js/bootstrapValidator.js"></script>	
	<script src="<?php echo $server; ?>plugins/select2/select2.full.js"></script>		
	<script src="<?php echo $server; ?>bootstrap/js/moment.min.js"></script>
	<script src="<?php echo $server; ?>plugins/daterangepicker/daterangepicker.js"></script>
	<script src="<?php echo $server; ?>plugins/datepicker/bootstrap-datepicker.js"></script>
	<script src="<?php echo $server; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script src="<?php echo $server; ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo $server; ?>plugins/fastclick/fastclick.min.js"></script>
	<script src="<?php echo $server; ?>dist/js/app.min.js"></script>
	<script src="<?php echo $server; ?>dist/js/demo.js"></script>
	<script src="<?php echo $server; ?>bootstrap/js/raphael-min.js"></script>
	<script src="<?php echo $server; ?>bootstrap/js/moment.js"></script>
	<script src="<?php echo $server; ?>bootstrap/js/function.mine.js"></script>	
    <script src="<?php echo $server; ?>js.mine/function.mine.js"></script>
    <script src="<?php echo $server; ?>dist/sweetalert/sweetalert-dev.js"></script>
	<script src="<?php echo $server; ?>plugins/ckeditor/ckeditor.js"></script>
	
	<script>
		$.widget.bridge('uibutton', $.ui.button); 	
      	$(function () {
        	$(".select2").select2();
      	});
	</script>
	
