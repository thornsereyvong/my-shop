<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>ZOBENZ</b>
	</div>
	<strong>Copyright &copy; 2015 <a target="_blank"
		href="http://zobenz.com">zobenz.com</a>.
	</strong> All rights reserved.
</footer>
<div class="control-sidebar-bg"></div>
