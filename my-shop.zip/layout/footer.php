<footer id="footer" class="footer-container">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="widget col-lg-3 col-md-6 col-sm-6 col-xs-12 col-sp-12">
								<div class="widget-html block">
									<div class="block_content">
										<div class="about">
											<a href="#"><img class="img-responsive"
												src="<?php echo $server; ?>themes/leo_clothing/img/modules/leomanagewidgets/logo.png"
												alt="" /></a>
											<p>Proin gravida nibh vel velit auctor aliquet. Aenean
												sollicitudin, lorem quis bibendum auctor, nisi elit consequat</p>
											<p>Lipsum, nec sagittis sem nibh id elit. Duis sed odio
												sit amet nibh vulputate cursus a sit amet mauris.</p>
										</div>
									</div>
								</div>
							</div>
							<div class="widget col-lg-2 col-md-6 col-sm-6 col-xs-12 col-sp-12">
								<section id="social_block" class="block footer-block">
									<h4 class="title_block">Get social</h4>
									<ul>
										<li class="facebook"><a class="_blank"
											href="http://www.facebook.com/prestashop"> <span>Facebook</span>
										</a></li>
										<li class="twitter"><a class="_blank"
											href="http://www.twitter.com/prestashop"> <span>Twitter</span>
										</a></li>
										<li class="rss"><a class="_blank"
											href="http://www.prestashop.com/blog/en/"> <span>RSS</span>
										</a></li>
										<li class="youtube"><a class="_blank"
											href="https://www.youtube.com/"> <span>Youtube</span>
										</a></li>
										<li class="google-plus"><a class="_blank"
											href="https://www.google.com/+prestashop"> <span>Google
													Plus</span>
										</a></li>
									</ul>
								</section>
								<div class="clearfix"></div>
							</div>
							<div class="widget col-lg-2 col-md-6 col-sm-6 col-xs-12 col-sp-12">
								<div class="footer-block block" id="block_various_links_footer">
									<h4 class="title_block">Information</h4>
									<ul class="toggle-footer list-group bullet">
										<li class="item"><a href="prices-drop.html"
											title="Specials"> Specials </a></li>
										<li class="item"><a href="new-products.html"
											title="New products"> New products </a></li>
										<li class="item"><a href="best-sales.html"
											title="Best sellers"> Best sellers </a></li>
										<li class="item"><a href="stores.html" title="Our stores">
												Our stores </a></li>
										<li class="item"><a href="content/4-about-us.html"
											title="About us"> About us </a></li>
									</ul>
								</div>
							</div>
							<div class="widget col-lg-2 col-md-6 col-sm-6 col-xs-12 col-sp-12">
								<div class="widget-links block footer-block">
									<h4 class="title_block">Help & More</h4>
									<div class="block_content">
										<div id="tabs1255379488" class="panel-group">
											<ul class="nav-links toggle-footer list-group bullet">
												<li><a href="#link1">Returns</a></li>
												<li><a href="#link2">F.A.Q</a></li>
												<li><a href="#link3">Shipping Policy</a></li>
												<li><a href="#link4">Search Terms</a></li>
												<li><a href="#link5">Contact Us</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div class="widget col-lg-3 col-md-6 col-sm-6 col-xs-12 col-sp-12">
								<div class="widget-html block">
									<h4 class="title_block">Contact</h4>
									<div class="block_content">
										<ul class="contact-us ileft">
											<li><span class="icon-box image"><em
													class="fa fa-home">&nbsp; </em></span>
												<p>No 1104 Sky Tower, Las Vegas, USA .</p></li>
											<li><span class="icon-box image"><em
													class="fa fa-phone">&nbsp; </em></span>
												<p>Phone: +84 (0) 123456789</p></li>
											<li><span class="icon-box image"><em
													class="fa fa-envelope">&nbsp; </em></span>
												<p>Mail: support@support.com</p></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</footer>