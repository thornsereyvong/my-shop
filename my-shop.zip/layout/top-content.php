<div class="widget col-lg-4 col-md-4 col-sm-12 col-xs-12 col-sp-12">
	<div class="widget-html block">
		<div class="block_content">
			<div class=" banner-image">
				<div class="top-banner">
					<h6>
						<a href="#">JADE JASON</a>
					</h6>
					<h4>
						<a href="#">MAN</a>
					</h4>
					
				</div>
				<a href="#"><img class="img-responsive"
					src="<?php echo $server; ?>themes/leo_clothing/img/modules/leomanagewidgets/home_adv_1.jpg"
					alt="" /></a>
			</div>
		</div>
	</div>
</div>
<div
	class="widget col-lg-4 col-md-4 col-sm-12 col-xs-12 col-sp-12">
	<div class="widget-html block">
		<div class="block_content">
			<div class=" banner-image">
				<a href="#"><img class="img-responsive"
					src="<?php echo $server; ?>themes/leo_clothing/img/modules/leomanagewidgets/home_adv_2.jpg"
					alt="" /></a>
				<div class="top-banner">
					<h6>
						<a href="#">JADE JASON</a>
					</h6>
					<h4>
						<a href="#">KIDS</a>
					</h4>
					<p></p>
				</div>
			</div>
		</div>
	</div>
</div>
<div
	class="widget col-lg-4 col-md-4 col-sm-12 col-xs-12 col-sp-12">
	<div class="widget-html block">
		<div class="block_content">
			<div class=" banner-image">
				<div class="top-banner">
					<h6>
						<a href="#">JADE JASON</a>
					</h6>
					<h4>
						<a href="#">WOMEN</a>
					</h4>
					
				</div>
				<a href="#"><img class="img-responsive"
					src="<?php echo $server; ?>themes/leo_clothing/img/modules/leomanagewidgets/home_adv_3.jpg"
					alt="" /></a>
			</div>
		</div>
	</div>
</div>